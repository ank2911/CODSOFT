<script setup>
import Navbar from './common/Navbar.vue';
</script>

<template>

  <Navbar/>
  
</template>