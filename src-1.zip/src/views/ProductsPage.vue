<script setup>
import ProductListingPage from '@/plp/ProductListingPage.vue';
</script>

<template>

  <div class="products">
    <h2>Products Page</h2>
    <ProductListingPage/>
  </div>

</template>
